#!/usr/bin/env python3
"""
valuation.py - deterministic valuation calculator for the stock-valuation-engine (VALU v2) skill.
Feeds the large-cap-put-overreaction (LC) skill through the VALU_HANDOFF line (val_floor).
Stdlib only. Missing inputs print 'n/a' or UNVERIFIED; the script never crashes on gaps.

  python3 valuation.py valu '<json>'     # inline JSON, a file path, or '-' for stdin

Units: statement money in $ MILLIONS (Zacks native; divide SEC raw dollars by 1e6). shares in MILLIONS.
spot / EPS / prices per share. Rates as decimals (0.045) or % (4.5). Peer pe/ps/peg as printed;
peer chg4w / chg12w and est_rev_4wk in percent points (-5.3 = -5.3%), as Zacks prints them.
Growth overrides g.bear/base/bull as decimals (0.08).
Zacks quarterly cash flow is YEAR-TO-DATE: pass it as returned with cf_mode "ytd" (default) plus fy_end.
"""
import json
import sys
from datetime import date, datetime

GT = 0.025  # terminal growth


# ---------- helpers ----------
def f(v):
    try:
        return None if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return None


def rate(v):
    v = f(v)
    return None if v is None else (v / 100.0 if abs(v) > 1 else v)


def d(s):
    if not s:
        return None
    try:
        return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def m(x, dp=2):
    return "n/a" if x is None else f"{x:,.{dp}f}"


def p(x, dp=1):
    return "n/a" if x is None else f"{x * 100:+.{dp}f}%"


def pa(x, dp=1):
    return "n/a" if x is None else f"{x * 100:.{dp}f}%"


def bigm(x):
    """$ millions -> readable."""
    if x is None:
        return "n/a"
    a, sg = abs(x), ("-" if x < 0 else "")
    return f"{sg}${a / 1e3:,.2f}B" if a >= 1e3 else f"{sg}${a:,.0f}M"


def median(xs):
    xs = sorted(v for v in xs if v is not None)
    if not xs:
        return None
    n = len(xs)
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2


def months(a, b):
    """Whole months from date a to date b."""
    return (b.year * 12 + b.month) - (a.year * 12 + a.month)


def load(arg):
    if arg == "-":
        return json.load(sys.stdin)
    if arg.strip().startswith("{"):
        return json.loads(arg)
    with open(arg) as fh:
        return json.load(fh)


# ---------- cash flow: YTD -> discrete quarters and TTM ----------
def fiscal_q(end, fy_end):
    """1..4 fiscal quarter of a period end (4 = fiscal year end). Rounds to the nearest quarter,
    so 52/53-week calendars (Sep 27, Jan 1) still map correctly."""
    if not end or not fy_end:
        return None
    q = int(round((months(fy_end, end) % 12) / 3.0)) % 4
    return 4 if q == 0 else q


def cf_series(rows, fy_end, mode):
    """rows: [{end, ocf, capex, da?}] any order.
    Returns (ttm_ocf, ttm_capex, quarters newest-first, note, ttm_da)."""
    recs = []
    for r in rows or []:
        e = d(r.get("end"))
        if e:
            da = f(r.get("da"))
            recs.append({"end": e, "ocf": f(r.get("ocf")), "capex": abs(f(r.get("capex")) or 0.0),
                         "da": None if da is None else abs(da)})
    recs.sort(key=lambda r: r["end"], reverse=True)
    if not recs:
        return None, None, [], "no cash-flow rows", None
    sub = lambda a, b: None if (a is None or b is None) else a - b
    add3 = lambda a, b, c: None if None in (a, b, c) else a + b - c
    if mode == "discrete":
        qs = recs[:4]
        if len(qs) < 4 or any(r["ocf"] is None for r in qs):
            return None, None, qs, "fewer than 4 discrete quarters", None
        da = sum(r["da"] for r in qs) if all(r["da"] is not None for r in qs) else None
        return sum(r["ocf"] for r in qs), sum(r["capex"] for r in qs), qs, "discrete quarters summed", da
    if not fy_end:
        return None, None, [], "cf_mode ytd needs fy_end (Zacks lst_com_fy)", None
    for r in recs:
        r["fq"] = fiscal_q(r["end"], fy_end)
    # discrete quarters: Q1 = YTD; otherwise YTD minus the previous quarter's YTD (3 months earlier)
    qs = []
    for i, r in enumerate(recs):
        if r["ocf"] is None:
            continue
        if r["fq"] == 1:
            qs.append({"end": r["end"], "ocf": r["ocf"], "capex": r["capex"], "da": r["da"]})
        elif i + 1 < len(recs) and recs[i + 1]["ocf"] is not None and abs(months(recs[i + 1]["end"], r["end"]) - 3) <= 1:
            o = recs[i + 1]
            qs.append({"end": r["end"], "ocf": r["ocf"] - o["ocf"], "capex": r["capex"] - o["capex"],
                       "da": sub(r["da"], o["da"])})
    L = recs[0]
    if L["ocf"] is None:
        return None, None, qs, "latest cash-flow row empty", None
    if L["fq"] == 4:
        return L["ocf"], L["capex"], qs, f"latest row is fiscal year {L['end']}", L["da"]
    fy = next((r for r in recs[1:] if r["fq"] == 4 and r["ocf"] is not None), None)
    prior = next((r for r in recs[1:] if abs(months(r["end"], L["end"]) - 12) <= 1 and r["ocf"] is not None), None)
    if fy and prior:
        return (L["ocf"] + fy["ocf"] - prior["ocf"], L["capex"] + fy["capex"] - prior["capex"], qs,
                f"TTM = YTD {L['end']} + FY {fy['end']} - prior YTD {prior['end']}",
                add3(L["da"], fy["da"], prior["da"]))
    if len(qs) >= 4:
        q4 = qs[:4]
        da = sum(r["da"] for r in q4) if all(r["da"] is not None for r in q4) else None
        return (sum(r["ocf"] for r in q4), sum(r["capex"] for r in q4), qs,
                "TTM = last 4 de-cumulated quarters", da)
    return None, None, qs, "not enough YTD rows for TTM (pass 5 quarterly rows)", None


# ---------- DCF ----------
def dcf_ev(fcf0, g, r, gt=GT, years=10, stage1=5):
    """Owner FCF grows at g for `stage1` years, fades linearly to gt by year `years`, then Gordon terminal."""
    if fcf0 is None or g is None or r is None or r <= gt:
        return None
    pv, cf = 0.0, fcf0
    for t in range(1, years + 1):
        gr = g if t <= stage1 else g + (gt - g) * (t - stage1) / float(years - stage1)
        cf *= (1 + gr)
        pv += cf / (1 + r) ** t
    return pv + cf * (1 + gt) / (r - gt) / (1 + r) ** years


def implied_g(fcf0, ev, r):
    """Stage-1 growth that makes the DCF equal today's EV (reverse DCF)."""
    if not fcf0 or fcf0 <= 0 or ev is None or ev <= 0 or r is None or r <= GT:
        return None
    lo, hi = -0.50, 1.00
    if dcf_ev(fcf0, hi, r) < ev:
        return hi  # implies > 100%/yr: pegged at the cap
    if dcf_ev(fcf0, lo, r) > ev:
        return lo
    for _ in range(80):
        mid = (lo + hi) / 2
        if dcf_ev(fcf0, mid, r) < ev:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


# ---------- main ----------
def valu(x):
    T_ = x.get("ticker", "?")
    asof = d(x.get("asof")) or date.today()
    S = f(x.get("spot"))
    fy_end = d(x.get("fy_end"))
    shares = f(x.get("shares"))
    mcap = f(x.get("mcap"))
    if shares is None and mcap and (f(x.get("mcap_px")) or S):
        shares = mcap / (f(x.get("mcap_px")) or S)
    if S and shares:
        mcap = S * shares  # re-mark to the live spot
    cash, debt, sbc = f(x.get("cash")), f(x.get("debt")), f(x.get("sbc_ttm"))
    fin = bool(x.get("financial"))
    unver = []
    print(f"{T_} | asof {asof} | spot {m(S)} | mcap {bigm(mcap)} | shares {m(shares, 1)}M | cash {bigm(cash)} debt {bigm(debt)}")
    if S is None:
        unver.append("spot")
    if shares is None:
        unver.append("shares/mcap")

    # ---- 1. last 4 earnings ----
    sur = [s for s in (x.get("surprises") or []) if f(s.get("act")) is not None and f(s.get("est")) is not None][-4:]
    beats = sum(1 for s in sur if f(s["act"]) >= f(s["est"]))
    avg_sur = (sum((f(s["act"]) - f(s["est"])) / abs(f(s["est"])) for s in sur if f(s["est"])) / len(sur)) if sur else None
    sales_q = [f(v) for v in (x.get("sales_q") or [])]
    revs = [f(r.get("rev")) for r in sorted((r for r in (x.get("is_q") or []) if d(r.get("end"))), key=lambda r: d(r["end"]))]
    if len(revs) > len(sales_q) and None not in revs:
        sales_q = revs  # 8 discrete snapshot quarters beat Zacks' 7-actual estimate table
    eps_q = [f(v) for v in (x.get("eps_adj_q") or [])]

    def yoy(series):
        out = []
        for k in range(4, 0, -1):  # oldest of the last 4 first
            i = len(series) - k
            if i - 4 >= 0 and series[i] is not None and series[i - 4]:
                out.append(series[i] / series[i - 4] - 1)
            else:
                out.append(None)
        return out

    s_yoy, e_yoy = yoy(sales_q), yoy(eps_q)
    sales_ttm = sum(sales_q[-4:]) if len(sales_q) >= 4 and None not in sales_q[-4:] else None
    sales_prev = sum(sales_q[-8:-4]) if len(sales_q) >= 8 and None not in sales_q[-8:-4] else None
    ttm_sales_g = (sales_ttm / sales_prev - 1) if (sales_ttm and sales_prev) else None
    trend = "n/a"
    known = [v for v in s_yoy if v is not None]
    if len(known) >= 2:
        dlt = known[-1] - known[0]
        trend = ("SHRINKING" if known[-1] < 0 else
                 "ACCELERATING" if dlt > 0.02 else "DECELERATING" if dlt < -0.02 else "STEADY")
    allq = sorted((r for r in (x.get("is_q") or []) if d(r.get("end"))), key=lambda r: d(r["end"]))
    isq = allq[-4:]
    ni_ttm = sum(f(r.get("ni")) for r in isq) if len(isq) == 4 and all(f(r.get("ni")) is not None for r in isq) else None
    eps_gaap_ttm = sum(f(r.get("eps")) for r in isq) if len(isq) == 4 and all(f(r.get("eps")) is not None for r in isq) else None
    eps_adj_ttm = sum(eps_q[-4:]) if len(eps_q) >= 4 and None not in eps_q[-4:] else None
    margins = [f(r.get("op_inc")) / f(r.get("rev")) for r in isq if f(r.get("op_inc")) is not None and f(r.get("rev"))]
    print(f"Earnings (last {len(sur)}): beats {beats}/{len(sur)} | avg EPS surprise {p(avg_sur)} | "
          f"sales YoY {' / '.join(p(v, 0) for v in s_yoy)} -> {trend} | adj EPS YoY {' / '.join(p(v, 0) for v in e_yoy)} | "
          f"op margin {' / '.join(pa(v, 0) for v in margins) or 'n/a'}"
          f"{'' if f(x.get('est_rev_4wk')) is None else ' | FY EPS est 4wk ' + p(f(x.get('est_rev_4wk')) / 100)}")

    # ---- 1b. core earnings: strip non-operating items (equity marks, investment gains) ----
    # SBC is already expensed inside operating income: never subtract it again from EPS/EBIT/NOPAT.
    pre = [f(r.get("pretax")) for r in isq]
    txs = [f(r.get("tax")) for r in isq]
    op_ttm = sum(f(r.get("op_inc")) for r in isq) if len(isq) == 4 and all(f(r.get("op_inc")) is not None for r in isq) else None
    pretax_ttm = sum(pre) if len(pre) == 4 and None not in pre else None
    t_in = rate(x.get("tax_rate"))
    if pretax_ttm and pretax_ttm > 0 and len(txs) == 4 and None not in txs:
        tax_r, tax_src = min(0.25, max(0.10, sum(txs) / pretax_ttm)), "TTM effective, clamped 10-25%"
    else:
        tax_r, tax_src = (t_in, "input") if t_in is not None else (0.21, "ASSUMED 21%")
    # recurring interest stays in core earnings: core pre-tax = op income - interest expense (when known)
    ie = [f(r.get("int_exp")) for r in isq]
    int_ttm = sum(abs(v) for v in ie) if len(ie) == 4 and None not in ie else None
    core_pre = (op_ttm - (int_ttm or 0)) if op_ttm is not None else None
    nonop = (pretax_ttm - core_pre) if (pretax_ttm is not None and core_pre is not None) else None
    # with interest unknown, a net non-operating EXPENSE is assumed to be recurring interest: only gains get flagged
    nonop_flag = bool(nonop is not None and op_ttm and abs(nonop) > 0.15 * abs(op_ttm)
                      and (nonop > 0 or int_ttm is not None))
    core_eps = core_pre * (1 - tax_r) / shares if (core_pre and shares) else None
    # forward core EPS, to match peers' forward (current-FY) P/E:
    #  (a) consensus F1 minus the one-off marks already booked this fiscal year (after tax), else
    #  (b) core TTM EPS grown by TTM operating-income growth for the months left until FY end
    eps_f1 = f(x.get("eps_f1"))
    prevq = allq[-8:-4]
    op_prev = sum(f(r.get("op_inc")) for r in prevq) if len(prevq) == 4 and all(f(r.get("op_inc")) is not None for r in prevq) else None
    g_op = max(-0.20, min(0.30, op_ttm / op_prev - 1)) if (op_ttm and op_prev and op_prev > 0) else None
    lastq = d(isq[-1]["end"]) if isq else None
    fy1_end = None
    if fy_end and lastq:
        fy1_end = fy_end
        while months(fy1_end, lastq) > 0:
            fy1_end = date(fy1_end.year + 1, fy1_end.month, min(fy1_end.day, 28))
    m_left = months(lastq, fy1_end) if (lastq and fy1_end) else None
    core_f1, core_f1_src = None, "n/a"
    if core_eps and core_eps > 0:
        ytd = [r for r in isq if fy_end and d(r["end"]) > fy_end]
        ytd_marks = None
        if ytd and all(f(r.get("pretax")) is not None and f(r.get("op_inc")) is not None for r in ytd):
            ytd_marks = sum(f(r.get("pretax")) - (f(r.get("op_inc")) - abs(f(r.get("int_exp")) or 0)) for r in ytd)
        elif fy_end and lastq and not ytd:
            ytd_marks = 0.0  # new fiscal year, nothing booked yet
        a = (eps_f1 - ytd_marks * (1 - tax_r) / shares) if (eps_f1 and ytd_marks is not None and shares) else None
        b = core_eps * (1 + g_op) ** (m_left / 12.0) if (g_op is not None and m_left is not None) else None
        if a and a > 0 and 0.7 <= a / core_eps <= 1.6:
            core_f1, core_f1_src = a, f"consensus F1 {m(eps_f1)} minus {bigm(ytd_marks)} of FY-to-date marks after tax"
        elif b:
            core_f1, core_f1_src = b, f"core TTM x (1 {p(g_op, 0)} op-income growth)^({m_left}/12)"
        else:
            core_f1, core_f1_src = core_eps, "core TTM (no growth data: conservative)"
    if nonop is not None:
        print(f"Core earnings: op income TTM {bigm(op_ttm)} | interest {bigm(int_ttm) if int_ttm is not None else 'n/a (net expense assumed recurring)'} | "
              f"pre-tax {bigm(pretax_ttm)} | non-operating ex-interest {bigm(nonop)} "
              f"({p(nonop / op_ttm if op_ttm else None, 0)} of op income) -> "
              f"{'NON-OP DISTORTION: GAAP EPS and EPS estimates include one-off marks' if nonop_flag else 'clean'} | "
              f"core EPS = (op income - interest) x (1 - {pa(tax_r)} [{tax_src}]) / shares = {m(core_eps)} vs GAAP TTM {m(eps_gaap_ttm)}"
              + (f" | forward core EPS {m(core_f1)} ({core_f1_src})" if nonop_flag else ""))

    # ---- 2. owner cash flow ----
    ocf, capex, qs, cf_note, da_ttm = cf_series(x.get("cf_q"), fy_end, x.get("cf_mode", "ytd"))
    fcf = (ocf - capex) if (ocf is not None and capex is not None) else None
    owner = (fcf - sbc) if (fcf is not None and sbc is not None) else None
    if owner is None and not fin:
        unver.append("owner FCF (OCF/CapEx/SBC)")
    conv = owner / ni_ttm if (owner is not None and ni_ttm and ni_ttm > 0) else None
    gap = (eps_adj_ttm / eps_gaap_ttm - 1) if (eps_adj_ttm and eps_gaap_ttm and eps_gaap_ttm > 0) else None
    print(f"Owner cash: OCF {bigm(ocf)} - CapEx {bigm(capex)} - SBC {bigm(sbc)} = owner FCF {bigm(owner)} "
          f"({cf_note}) | SBC/OCF {pa(sbc / ocf if (sbc is not None and ocf) else None)} | owner FCF / GAAP NI "
          f"{m(conv)}x | adj EPS vs GAAP {p(gap, 0)}")
    if qs:
        print("  quarters (de-cumulated, newest first): " +
              " | ".join(f"{r['end']} OCF {bigm(r['ocf'])} capex {bigm(r['capex'])}" for r in qs[:4]))
    quality = "n/a"
    if conv is not None or gap is not None:
        bad = (conv is not None and conv < 0.7) or (gap is not None and gap > 0.40) or \
              (sbc is not None and ocf and sbc / ocf > 0.25)
        quality = "LOW (cash or GAAP gap)" if bad else "OK"

    # ---- 3. market (Zacks compare_stocks: raw and S&P-relative % changes; S&P move = (1+t)/(1+rel) - 1) ----
    pc = lambda k: (f(x.get(k)) / 100) if f(x.get(k)) is not None else None
    t4, t12, rel4, rel12 = pc("t_chg4w"), pc("t_chg12w"), pc("t_rel4w"), pc("t_rel12w")
    s4 = ((1 + t4) / (1 + rel4) - 1) if (t4 is not None and rel4 is not None) else None
    s12 = ((1 + t12) / (1 + rel12) - 1) if (t12 is not None and rel12 is not None) else None
    # Zacks moves are as of its last close; re-mark the stock's leg to the live spot (S&P backed out first, left as is)
    zpx = f(x.get("zacks_px"))
    remark = (S / zpx) if (S and zpx) else None
    if remark:
        t4 = (1 + t4) * remark - 1 if t4 is not None else None
        t12 = (1 + t12) * remark - 1 if t12 is not None else None
    beta = f(x.get("beta"))
    peers = x.get("peers") or []
    p12 = median([f(q.get("chg12w")) / 100 if f(q.get("chg12w")) is not None else None for q in peers])
    mkt_part = beta * s12 if (beta is not None and s12 is not None) else None
    resid = (t12 - mkt_part) if (t12 is not None and mkt_part is not None) else None
    idio = (t12 - p12) if (t12 is not None and p12 is not None) else None
    cls = "n/a"
    if t12 is not None:
        # relative first: a flat stock in a rising tape is still a company-specific move
        if idio is not None and abs(idio) >= 0.08:
            cls = "COMPANY-SPECIFIC (" + ("lagging" if idio < 0 else "leading") + " peers)"
        elif abs(t12) < 0.05 and (resid is None or abs(resid) < 0.05):
            cls = "NO MAJOR MOVE"
        elif resid is not None and abs(resid) < 0.05:
            cls = "MARKET-DRIVEN"
        elif p12 is not None and abs(t12) >= 0.05 and abs(p12) >= 0.05 and (t12 < 0) == (p12 < 0):
            cls = "SECTOR-WIDE"
        else:
            cls = "MIXED (" + ("behind" if (resid or 0) < 0 else "ahead of") + " the market, within 8 pts of peers)"
    print(f"Market: beta {m(beta)} | 12w: stock {p(t12)} S&P {p(s12)} peers med {p(p12)} | market-explained "
          f"{p(mkt_part)} residual {p(resid)} | vs peers {p(idio)} -> {cls} | 4w: stock {p(t4)} S&P {p(s4)}"
          + (f" | stock leg re-marked to spot ({p(remark - 1)} vs Zacks close {m(zpx)})" if remark
             else " | UNVERIFIED: moves as of the Zacks close (pass zacks_px)"))

    # ---- 4. valuation ----
    rf = rate(x.get("rf")) or 0.045
    erp = rate(x.get("erp")) or 0.05
    r = min(0.14, max(0.07, rf + (beta if beta is not None else 1.0) * erp))
    ev = (mcap + (debt or 0) - (cash or 0)) if mcap else None
    if debt is None or cash is None:
        unver.append("cash/debt")
    eq = (lambda e: (e - (debt or 0) + (cash or 0)) / shares if (e is not None and shares) else None)
    eps_f2 = f(x.get("eps_f2"))
    eps_g = (eps_f2 / eps_f1 - 1) if (eps_f1 and eps_f2 and eps_f1 > 0) else None
    cands = [v for v in ((None if nonop_flag else eps_g), ttm_sales_g) if v is not None]
    gin = x.get("g") or {}
    g_base = rate(gin.get("base"))
    if g_base is None:
        g_base = max(-0.05, min(0.20, sum(cands) / len(cands))) if cands else None
    g_bear = rate(gin.get("bear"))
    g_bull = rate(gin.get("bull"))
    if g_base is not None:
        if g_bear is None:
            g_bear = g_base - max(0.05, 0.5 * abs(g_base))
        if g_bull is None:
            g_bull = min(0.30, g_base + max(0.03, 0.5 * abs(g_base)))
    dcf_ok = owner is not None and owner > 0 and not fin
    v_bear = eq(dcf_ev(owner, g_bear, r + 0.01)) if dcf_ok else None
    v_base = eq(dcf_ev(owner, g_base, r)) if dcf_ok else None
    v_bull = eq(dcf_ev(owner, g_bull, r - 0.005)) if dcf_ok else None
    v_base_up = eq(dcf_ev(owner, g_base, r + 0.01)) if dcf_ok else None
    ig = implied_g(owner, ev, r) if dcf_ok else None
    ig_up = implied_g(owner, ev, r + 0.01) if dcf_ok else None
    if not dcf_ok and not fin:
        print("DCF: n/m - owner FCF <= 0 or missing (no owner cash to discount)")
    print(f"Rates: r = rf {pa(rf)}{'' if x.get('rf') is not None else ' (ASSUMED)'} + beta x ERP {pa(erp)} = {pa(r)} | "
          f"+100bp -> base value {p((v_base_up / v_base - 1) if (v_base and v_base_up) else None)}")
    print(f"Reverse DCF: price implies {p(ig)} owner-FCF growth/yr for 5y (fading to {pa(GT)}) at r {pa(r)}; "
          f"{p(ig_up)} at r +1% | inputs: EPS F1->F2 {p((eps_f2 / eps_f1 - 1) if (eps_f1 and eps_f2 and eps_f1 > 0) else None)}, "
          f"TTM sales {p(ttm_sales_g)}{' (EPS leg dropped: non-op distortion)' if nonop_flag else ''}")
    # capex-normalized lens: maintenance capex = max(TTM D&A, run-rate D&A, PP&E / life); the rest is growth capex.
    # No-growth value (EPV) is a SOFT floor.
    capex_surge = bool(da_ttm and capex is not None and capex > 2 * da_ttm)
    da_run = qs[0]["da"] * 4 if (qs and qs[0].get("da")) else None
    ppe, life = f(x.get("ppe_net")), f(x.get("ppe_life")) or 10.0
    maint_c = [("TTM D&A", da_ttm), ("run-rate D&A (last qtr x4)", da_run), (f"net PP&E / {life:.0f}y", ppe / life if ppe else None)]
    maint_src, maint = max(((k, v) for k, v in maint_c if v), key=lambda kv: kv[1], default=(None, None))
    owner_norm = (ocf - sbc - maint) if (ocf is not None and sbc is not None and maint) else None
    fcf_norm = (ocf - maint) if (ocf is not None and maint) else None
    epv = eq(owner_norm / r) if (owner_norm and owner_norm > 0 and not fin) else None
    ig_norm = implied_g(owner_norm, ev, r) if (owner_norm and owner_norm > 0 and not fin) else None
    norm_on = owner_norm is not None and not fin and (capex_surge or not dcf_ok)
    if not norm_on:
        epv = ig_norm = None
    if norm_on:
        print(f"Capex-normalized: CapEx {bigm(capex)} = {m(capex / da_ttm if da_ttm else None, 1)}x D&A {bigm(da_ttm)}"
              f"{' (SURGE > 2x)' if capex_surge else ''} | maintenance capex = {maint_src} {bigm(maint)} | "
              f"OCF - SBC - maintenance = normalized owner FCF {bigm(owner_norm)} | "
              f"no-growth value (EPV = norm FCF / r + net cash) {m(epv)}/sh = SOFT floor | "
              f"price implies {p(ig_norm)} normalized growth/yr for 5y")
    print(f"DCF/sh: bear {m(v_bear)} (g {p(g_bear)}, r {pa(r + 0.01)}) | base {m(v_base)} (g {p(g_base)}) | "
          f"bull {m(v_bull)} (g {p(g_bull)}, r {pa(r - 0.005)})")

    # own history: P/FCF at each fiscal year's low (current share count: buybacks make past multiples look lower -> conservative)
    pm = x.get("px_m") or {}
    bars = [(d(str(t)[:7] + "-01"), f(lo)) for t, lo in zip(pm.get("t") or [], pm.get("l") or [])]
    bars = [(t, lo) for t, lo in bars if t and lo is not None]
    hist = []
    for a in x.get("annual") or []:
        e = d(a.get("end"))
        fa = (f(a.get("ocf")) - abs(f(a.get("capex")) or 0.0)) if f(a.get("ocf")) is not None else None
        sh_y = (f(a.get("ni")) / f(a.get("eps"))) if (f(a.get("ni")) and f(a.get("eps"))) else None
        if not sh_y or sh_y <= 0:
            sh_y = shares  # loss year or no EPS: fall back to today's count
        if not e or not fa or fa <= 0 or not sh_y:
            continue
        w = [lo for t, lo in bars if 0 <= months(t, e) <= 11]  # the 12 monthly bars ending in the FY-end month
        if len(w) >= 10:
            hist.append((e, min(w) * sh_y / fa))
    trough = min((v for _, v in hist), default=None)
    hmed = median([v for _, v in hist])
    pfcf = mcap / fcf if (mcap and fcf and fcf > 0) else None
    powner = mcap / owner if (mcap and owner and owner > 0) else None
    v_trough = trough * owner / shares if (trough and owner and owner > 0 and shares) else None
    v_hmed = hmed * fcf / shares if (hmed and fcf and fcf > 0 and shares) else None
    v_hmed_norm = hmed * fcf_norm / shares if (hmed and fcf_norm and fcf_norm > 0 and shares and norm_on) else None
    print(f"Own history ({len(hist)} FY): P/FCF at yearly lows {' / '.join(f'{e.year} {v:.1f}x' for e, v in hist) or 'n/a'} | "
          f"trough {m(trough, 1)}x median {m(hmed, 1)}x | now P/FCF {m(pfcf, 1)}x P/owner-FCF {m(powner, 1)}x | "
          f"trough x owner FCF = {m(v_trough)}/sh | median x FCF = {m(v_hmed)}/sh"
          + (f" | median x normalized FCF {bigm(fcf_norm)} = {m(v_hmed_norm)}/sh" if v_hmed_norm else ""))

    # peers
    pe_med = median([f(q.get("pe_f1")) for q in peers if (f(q.get("pe_f1")) or 0) > 0])
    ps_med = median([f(q.get("ps")) for q in peers if (f(q.get("ps")) or 0) > 0])
    peg_med = median([f(q.get("peg")) for q in peers if (f(q.get("peg")) or 0) > 0])
    pe_eps = core_f1 if nonop_flag else eps_f1
    # core EPS excludes interest income, so positive net cash is added back on that route (debt is already in via interest)
    nc_add = ((cash or 0) - (debt or 0)) / shares if (nonop_flag and shares and (cash or 0) > (debt or 0)) else 0.0
    pe_val = lambda med: (med * pe_eps + nc_add) if (med and pe_eps and pe_eps > 0) else None
    v_pe = pe_val(pe_med)
    pes = [f(q.get("pe_f1")) for q in peers]
    loo = [pe_val(median([v for j, v in enumerate(pes) if j != i and (v or 0) > 0])) for i in range(len(pes))] if len(pes) >= 3 else []
    loo = [v for v in loo if v is not None]
    v_ps = ps_med * sales_ttm / shares if (ps_med and sales_ttm and shares) else None
    t_pe = S / pe_eps if (S and pe_eps and pe_eps > 0) else None
    t_ps = mcap / sales_ttm if (mcap and sales_ttm) else None
    print(f"Peers ({', '.join(str(q.get('t')) for q in peers) or 'none'}): fwd P/E med {m(pe_med, 1)}x vs {m(t_pe, 1)}x "
          f"({p((t_pe / pe_med - 1) if (t_pe and pe_med) else None, 0)}) | P/S med {m(ps_med, 1)}x vs {m(t_ps, 1)}x | "
          f"PEG med {m(peg_med)} vs {m(f(x.get('peg')))} | implied/sh: "
          f"{'peer fwd P/E x forward core EPS + net cash ' + m(nc_add) + '/sh' if nonop_flag else 'fwd P/E'} {m(v_pe)}"
          f"{' (leave-one-peer-out ' + m(min(loo)) + '-' + m(max(loo)) + ')' if loo else ''} | P/S {m(v_ps)} (margin-blind)")
    if not peers:
        unver.append("peers")

    # ---- verdict ----
    floor = min([v for v in (v_bear, v_trough) if v is not None], default=None)
    if fin:
        floor = None
    fair = median([v_base, v_hmed_norm if (capex_surge and v_hmed_norm) else v_hmed, v_pe])
    if fin and fair is None:
        fair = v_pe
    if not dcf_ok and not fin and fair is not None:
        # no owner cash: peers plus own history on normalized FCF; margin-blind P/S is never the only comparable
        fair = median([v_pe, v_hmed_norm, v_ps] if v_hmed_norm else [v_pe, v_ps])
    mos = (fair / S - 1) if (fair and S) else None
    if fair is None or S is None:
        v = "INCOMPLETE: fair value needs owner FCF, peers or estimates"
    elif not dcf_ok and not fin:
        rel = "UNDERVALUED" if S < fair * 0.85 else "RICH" if S > fair * 1.15 else "FAIRLY VALUED"
        if capex_surge and epv:
            v = (f"CAPEX-CYCLE ({rel} vs peers): owner FCF negative from growth capex - "
                 f"fair from peers and normalized history, soft floor {m(epv)} (no-growth value)")
        else:
            v = "SPECULATIVE: no owner cash flow - value rests on peer multiples only"
    elif floor is not None and abs(S / floor - 1) <= 0.02:
        v = f"AT FLOOR: spot within 2% of the floor ({p(S / floor - 1)}) - no cushion"
    elif floor is not None and S < floor:
        v = f"DEEP VALUE: spot {p(S / floor - 1)} below the floor"
    elif S < fair * 0.85:
        v = "UNDERVALUED"
    elif S <= fair * 1.15:
        v = "FAIRLY VALUED"
    else:
        v = "RICH"
    print(f"Range/sh: floor {m(floor)} | fair {m(fair)} | bull {m(v_bull)} | spot {m(S)} -> margin of safety {p(mos)} | "
          f"earnings {trend}, quality {quality}, move {cls}")
    if unver:
        print("UNVERIFIED: " + ", ".join(unver))
    print("VERDICT: " + v)
    hand = {"ticker": T_, "asof": str(asof), "val_floor": None if floor is None else round(floor, 2),
            "val_fair": None if fair is None else round(fair, 2), "val_implied_g": None if ig is None else round(ig, 4),
            "val_r": round(r, 4), "val_trough_pfcf": None if trough is None else round(trough, 1),
            "val_soft_floor": None if epv is None else round(epv, 2),
            "val_implied_g_norm": None if ig_norm is None else round(ig_norm, 4),
            "val_core_eps": None if core_eps is None else round(core_eps, 2),
            "val_core_eps_f1": None if (core_f1 is None or not nonop_flag) else round(core_f1, 2), "val_nonop_flag": nonop_flag,
            "val_pe_range": [round(min(loo), 2), round(max(loo), 2)] if loo else None,
            "val_move": cls, "val_trend": trend, "val_verdict": v.split(":")[0]}
    print("VALU_HANDOFF " + json.dumps(hand))


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] != "valu":
        print(__doc__)
        sys.exit(1)
    valu(load(sys.argv[2]))
